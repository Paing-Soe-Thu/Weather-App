# Weather App

> Bu projeyi JavaScript pratiği yapmak için oluşturdum. Open Weather Map API'ı kullanarak hava durumu uygulaması yaptım

> Canlı Proje [_tıkla_](https://weather-app-chi-ivory-46.vercel.app/).

## İçerik
- [Weather App](#weather-app)
  - [İçerik](#i̇çerik)
  - [Genel Bilgi](#genel-bilgi)
  - [Kullanılan Teknolojiler](#kullanılan-teknolojiler)
  - [Features](#features)
  - [Projeye Bakış](#projeye-bakış)
  - [Proje Durumu](#proje-durumu)
  - [İletişim](#i̇letişim)

## İçerik
Hava durumu uygulaması

## Genel Bilgi
Projeyi klonladıktan sonra live server kullanarak localinizde çalıştırabilirsiniz.

## Kullanılan Teknolojiler
- HTML
- CSS
- JavaScript


## Features
- İsteğe ve açılan issue'lere bağlı olarak features eklenecektir. Proje bitmiştir.


## Projeye Bakış
![Bakış](https://github.com/busenurcetin/Weather-App/assets/110244548/db0e47fd-1d74-4f4d-961b-4ffe92718930)


## Proje Durumu
Proje bitti.

## İletişim
[Twitter - @busenurcetin16](https://twitter.com/busenurcetin16)
