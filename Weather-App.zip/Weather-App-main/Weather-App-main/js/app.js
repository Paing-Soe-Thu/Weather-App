const apiKey= "b5b3a8a96895fdfea295623af29004f1"
const apiUrl = "https://api.openweathermap.org/data/3.0/onecall?lat={lat}&lon={lon}&exclude={part}&appid={API key}";

const searchBox = document.querySelector(".search input");
const searchBtn = document.querySelector(".search button");
const weatherIcon = document.querySelector(".weather-icon");
const errorDiv = document.querySelector(".error");

errorDiv.style.display = "none";

async function checkWeather(city){
    const response = await fetch(apiUrl +city + `&appid=${apiKey}`);

    if(response.status == 404){
        errorDiv.style.display = "block";
        document.querySelector(".weather").style.display = "none";
        errorDiv.textContent = "City not found. Please try again.";
    } else if(response.status==400){
      alert("Please Enter a City Name");
    } else{

      var data = await response.json();

    document.querySelector(".city").innerHTML = data.name;
    document.querySelector(".temp").innerHTML = Math.round(data.main.temp)+ "°c"; 
    document.querySelector(".humidity").innerHTML = data.main.humidity+"%";
    document.querySelector(".wind").innerHTML = data.wind.speed+" km/h";
    
    if(data.weather[0].main =="Clouds"){
        weatherIcon.src = "images/clouds.png";
    }else if(data.weather[0].main =="Clear"){
        weatherIcon.src = "images/clear.png";
      }
      else if(data.weather[0].main =="Rain"){
        weatherIcon.src = "images/rain.png";
      }
      else if(data.weather[0].main =="Drizzle"){
        weatherIcon.src = "images/drizzle.png";
      }
      else if(data.weather[0].main =="Mist"){
        weatherIcon.src = "images/mist.png";
      }

      document.querySelector(".weather").style.display = "block";
      errorDiv.style.display = "none";
    }
}

searchBtn.addEventListener("click", ()=>{
    checkWeather(searchBox.value);
})

searchBox.addEventListener("keyup", (event)=>{
    if(event.key == "Enter"){
        checkWeather(searchBox.value);
    }
});
