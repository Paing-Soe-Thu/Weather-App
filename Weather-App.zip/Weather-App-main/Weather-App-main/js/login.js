// Add event listeners for login and sign-up forms
document.getElementById('signup-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('signup-username').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;

    // Call backend to handle sign-up with username, email, and password
    console.log("Signing up with", username, email);
    
    // After successful registration, switch to login form
    document.getElementById('signup-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
    
    // Optional: Clear the signup form
    e.target.reset();
});

document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
        const response = await fetch('http://localhost:5000/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
        });

        const data = await response.json();
        
        if (response.ok) {
            console.log("Login successful");
            window.location.href = 'home.html';
        } else {
            console.error(data.error);
            alert("Login failed. Please check your credentials.");
        }
    } catch (err) {
        console.error('Error:', err);
    }
});

// Google Login Success Callback
function handleCredentialResponse(response) {
    console.log("Encoded JWT ID token: " + response.credential);

    // Send the token to your backend to verify and create a session for the user
    // Example: await fetch('YOUR_BACKEND_URL', { method: 'POST', body: JSON.stringify({ token: response.credential }) })
}

window.onload = function () {
    google.accounts.id.initialize({
        client_id: "797696248480-c4d0qlebcj4ab0oa9vh5l9c5snj9js47.apps.googleusercontent.com",
        callback: handleCredentialResponse
    });
    google.accounts.id.renderButton(
        document.querySelector(".g_id_signin"), 
        { theme: "outline", size: "large" }
    );
    google.accounts.id.prompt(); // Shows the One Tap dialog if eligible
};
