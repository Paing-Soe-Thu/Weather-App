const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const session = require('express-session');
const path = require('path');

const app = express();
app.use(express.json());
app.use(cors());
app.use(session({
    secret: 'your_seGOCSPX-5hBirYbkWaJ_IuVyq6z9WIIXwcZ6cret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));
app.use(passport.initialize());
app.use(passport.session());

// Serve static files from the 'Weather-App-main' directory
app.use(express.static(path.join(__dirname, 'Weather-App-main')));

// Connect to MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Cat543211@',
    database: 'userlogin'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database');
});

// Configure Google Strategy
passport.use(new GoogleStrategy({
    clientID: '797696248480-c4d0qlebcj4ab0oa9vh5l9c5snj9js47.apps.googleusercontent.com',
    clientSecret: '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',
    callbackURL: "http://localhost:5000/auth/google/callback"
  },
  async function(accessToken, refreshToken, profile, cb) {
    try {
        // Check if user exists in database
        const sql = 'SELECT * FROM users WHERE email = ?';
        db.query(sql, [profile.emails[0].value], async (err, results) => {
            if (err) return cb(err);
            
            if (results.length === 0) {
                // Create new user if doesn't exist
                const insertSql = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
                db.query(insertSql, [profile.displayName, profile.emails[0].value, null], (err, result) => {
                    if (err) return cb(err);
                    return cb(null, { id: result.insertId, email: profile.emails[0].value });
                });
            } else {
                return cb(null, results[0]);
            }
        });
    } catch (error) {
        return cb(error);
    }
}));

// Serialize and deserialize user
passport.serializeUser((user, done) => {
    done(null, user.id); // Store the user ID in the session
});

passport.deserializeUser((id, done) => {
    const sql = 'SELECT * FROM users WHERE id = ?';
    db.query(sql, [id], (err, results) => {
        if (err) return done(err);
        done(null, results[0]); // Return the user object
    });
});

// Google auth routes
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

app.get('/auth/google/callback', 
  passport.authenticate('google', { failureRedirect: '/login' }),
  function(req, res) {
    // Successful authentication, redirect home
    const token = jwt.sign({ id: req.user.id }, 'secret_key');
    res.redirect(`/index.html?token=${token}`);
  }
);

// Registration Route
app.post('/register', async (req, res) => {
    const { username, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    const sql = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
    db.query(sql, [username, email, hashedPassword], (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).json({ error: 'Email already exists' });
            }
            return res.status(500).json({ error: 'Database error' });
        }
        res.json({ message: 'User registered successfully!' });
    });
});

// Login Route
app.post('/login', (req, res) => {
    const { email, password } = req.body;
    const sql = 'SELECT * FROM users WHERE email = ?';
    
    db.query(sql, [email], async (err, results) => {
        if (err) return res.status(500).json({ error: 'SignUp fail. Please retry!' });
        
        if (results.length === 0 || !(await bcrypt.compare(password, results[0].password))) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }
        
        const token = jwt.sign({ id: results[0].id }, 'secret_key');
        res.json({ 
            message: 'Login successful', 
            token,
            user: {
                id: results[0].id,
                username: results[0].username,
                email: results[0].email
            }
        });
    });
});

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
